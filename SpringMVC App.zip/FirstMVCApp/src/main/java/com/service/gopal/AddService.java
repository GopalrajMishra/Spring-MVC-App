package com.service.gopal;

public class AddService {
	
	public int add(int i,int j) {
		
		return i+j;
		
	}

}
